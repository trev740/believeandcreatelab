StreamLens OBS Plugin for Windows
=================================

Thank you for downloading the StreamLens OBS Plugin.

This plugin lets OBS Studio receive a wireless camera stream from the StreamLens iPhone app.

Requirements
------------

- Windows 10 or Windows 11
- OBS Studio 64-bit
- StreamLens app installed on your iPhone
- Your iPhone and computer connected to the same Wi-Fi network

Installation
------------

1. Close OBS Studio completely.

2. Open the StreamLens OBS Plugin Windows ZIP file.

3. Copy the included folders:

   data
   obs-plugins

   into your OBS Studio install folder.

   For most users, this folder is:

   C:\Program Files\obs-studio\

4. When Windows asks if you want to merge folders, choose Yes.

5. Reopen OBS Studio.

6. In OBS, click the + button in Sources.

7. Choose:

   StreamLens Device

8. Open StreamLens on your iPhone.

9. Make sure your iPhone and computer are on the same Wi-Fi network.

10. In the StreamLens app, tap:

    Search for Signal

11. When OBS is found, press LIVE in the app.

Expected folder layout
----------------------

After installation, your OBS folder should look like this:

C:\Program Files\obs-studio\
├─ obs-plugins\
│  └─ 64bit\
│     └─ streamlens-device.dll
└─ data\
   └─ obs-plugins\
      └─ streamlens-device\
         └─ StreamLensPlaceholder.png

Troubleshooting
---------------

If StreamLens Device does not appear in OBS:

1. Make sure OBS was fully closed before copying the files.
2. Make sure the files were copied into the real OBS Studio install folder.
3. Make sure you are using 64-bit OBS Studio.
4. Restart your computer and open OBS again.
5. Check that this file exists:

   C:\Program Files\obs-studio\obs-plugins\64bit\streamlens-device.dll

If the iPhone app cannot find OBS:

1. Make sure OBS is open.
2. Make sure StreamLens Device is added as a source in OBS.
3. Make sure your iPhone and computer are on the same Wi-Fi network.
4. Allow OBS through Windows Firewall if Windows asks.
5. Avoid guest Wi-Fi networks, VPNs, or networks that block local device discovery.

Uninstall
---------

Close OBS Studio, then delete these files/folders:

C:\Program Files\obs-studio\obs-plugins\64bit\streamlens-device.dll

C:\Program Files\obs-studio\data\obs-plugins\streamlens-device\

Support
-------

StreamLens by Believe N Create Lab.
